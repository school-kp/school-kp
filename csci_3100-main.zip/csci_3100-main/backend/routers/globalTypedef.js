/**
 * @callback RouteCallback
 * @global
 * @param {express.Request} req - Express request. 
 * @param {express.Response} res - Express response. 
 */

