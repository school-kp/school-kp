JSDocs in-code are exported as webpage in `/docs`. A non-updated version of the routes can be seen in `routes.md`.
