[
    {
        "photo": [
            "https://firebasestorage.googleapis.com/v0/b/csci3100-2bab5.appspot.com/o/0.41670335592495844%2F0.416703355924958441.jpg?alt=media&token=20b15c4c-383e-4d75-8389-7e2bcb909b5b",
            "https://firebasestorage.googleapis.com/v0/b/csci3100-2bab5.appspot.com/o/0.18556657675031518%2F0.185566576750315182.png?alt=media&token=7d9ffa18-fd0d-4784-8cb7-2ed5a809840e"
        ],
        "modifiedTime": [
            "2021-04-07T18:08:07.860Z"
        ],
        "hashtag": [
            {
                "_id": "606d6ab809d22f29107b89e5",
                "name": "hash1"
            },
            {
                "_id": "606dded3bf62314a103ac65c",
                "name": "bee2"
            },
            {
                "_id": "606dded3bf62314a103ac65d",
                "name": "cat3"
            },
            {
                "_id": "606dded3bf62314a103ac65e",
                "name": "four4"
            },
            {
                "_id": "606dded3bf62314a103ac65f",
                "name": "foiwefj5"
            }
        ],
        "like": [],
        "comment": [
            {
                "_id": "606df507bf62314a103ac666",
                "commentID": "usern-1424-1617818887828",
                "author": {
                    "profPhoto": [],
                    "type": "User",
                    "_id": "606b3b30ab2e811e0c8bd2f7",
                    "username": "usern",
                    "tag": "1424",
                    "entityID": "usern-1424"
                },
                "post": "606dded3bf62314a103ac65b",
                "content": "some text",
                "time": "2021-04-07T18:08:07.828Z",
                "__v": 0
            }
        ],
        "_id": "606dded3bf62314a103ac65b",
        "postID": "usern-1424-1617813203859",
        "author": {
            "profPhoto": [],
            "type": "User",
            "_id": "606b3b30ab2e811e0c8bd2f7",
            "username": "usern",
            "tag": "1424",
            "entityID": "usern-1424"
        },
        "target": {
            "profPhoto": [],
            "type": "Rest",
            "_id": "605a1bc56bf76f7ff6ecfdd3",
            "username": "jon-rest",
            "tag": "1296",
            "entityID": "jon-rest-1296"
        },
        "type": 0,
        "content": "content",
        "createdTime": "2021-04-07T16:33:23.859Z",
        "__v": 0
    },
    {
        "photo": [
            "https://firebasestorage.googleapis.com/v0/b/csci3100-2bab5.appspot.com/o/0.6639191101497417%2F0.66391911014974171.jpg?alt=media&token=289d6d62-2567-45ab-97ea-3c7e30f16707",
            "https://firebasestorage.googleapis.com/v0/b/csci3100-2bab5.appspot.com/o/0.014446559852700158%2F0.0144465598527001582.png?alt=media&token=4e8a5037-f079-4694-bc50-83f3ecdd1f86"
        ],
        "modifiedTime": [],
        "hashtag": [
            {
                "_id": "606de676bf62314a103ac661",
                "name": "afwe1"
            },
            {
                "_id": "606de676bf62314a103ac662",
                "name": "qwe12"
            },
            {
                "_id": "606de676bf62314a103ac663",
                "name": "rr3"
            },
            {
                "_id": "606de676bf62314a103ac664",
                "name": "a444"
            },
            {
                "_id": "606de676bf62314a103ac665",
                "name": "235"
            }
        ],
        "like": [],
        "comment": [],
        "_id": "606de676bf62314a103ac660",
        "postID": "usern-1424-1617815158871",
        "author": {
            "profPhoto": [],
            "type": "User",
            "_id": "606b3b30ab2e811e0c8bd2f7",
            "username": "usern",
            "tag": "1424",
            "entityID": "usern-1424"
        },
        "target": {
            "profPhoto": [],
            "type": "Rest",
            "_id": "605a1bc56bf76f7ff6ecfdd3",
            "username": "jon-rest",
            "tag": "1296",
            "entityID": "jon-rest-1296"
        },
        "type": 0,
        "content": "conttente2",
        "createdTime": "2021-04-07T17:05:58.871Z",
        "__v": 0
    }
]