/*
extracted from my-app\src\pages\panel_page\entity.js
*/
//Add this to our page?
import {WhatsappShareButton, WhatsappIcon,
    EmailShareButton,EmailIcon,
    FacebookShareButton, FacebookIcon} from "react-share";


<>
<WhatsappShareButton url="Hi! I am using mATE. Eat with me at http://localhost:3000/">
<WhatsappIcon></WhatsappIcon>
</WhatsappShareButton>

<EmailShareButton url="Hi! I am using mATE. Eat with me at http://localhost:3000/">
<EmailIcon></EmailIcon>
</EmailShareButton>

<FacebookShareButton url ="Hi! I am using mATE. Eat with me at http://localhost:3000/">
<FacebookIcon></FacebookIcon>
</FacebookShareButton>
</>