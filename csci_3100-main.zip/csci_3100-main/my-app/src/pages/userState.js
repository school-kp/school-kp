const state = 0;
localStorage.setItem("someVarKey", state);
export default{state};